'''
The module for first_inside_quotes

<YOUR NAME HERE>
<DATE HERE>
'''


# Add the function first_inside_quotes here